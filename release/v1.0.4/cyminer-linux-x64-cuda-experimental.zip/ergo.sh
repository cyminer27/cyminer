#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
./cyminer --mine --coin erg --pool erg.2miners.com:8888 --wallet "[WALLET ADDRESS]" --worker ArcWorker1
