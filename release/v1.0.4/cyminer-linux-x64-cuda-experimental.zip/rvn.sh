#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
./cyminer --mine --coin rvn --pool stratum+tcp://stratum.ravenminer.com:3800 --wallet "[WALLET ADDRESS]" --worker ArcWorker2
read -r -p 'Press Enter to continue...' _
