#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
./cyminer --mine --coin etc --pool etc.2miners.com:1010 --wallet "[WALLET ADDRESS]"
