#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
./cyminer --mine --coin xna --algo kawpow --pool us-xna.2miners.com:6060 --wallet "[WALLET ADDRESS]" --worker ArcWorker1
