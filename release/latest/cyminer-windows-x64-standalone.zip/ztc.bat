@echo off
cyminer.exe --mine --coin ztc --pool superblockchain.zapto.org:11150 --wallet [YOUR ZTC ADDRESS] --worker ArcWorker1
pause
