cyminer.exe --mine --coin mewc --pool pool.woolypooly.com:3116 --wallet [WALLET ADDRESS] --worker ArcWorker1


pause