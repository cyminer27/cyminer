cyminer.exe --mine --coin etc --pool etc.2miners.com:1010 --wallet [WALLET ADDRESS]
