cyminer.exe --mine --coin abrs --pool stratum+tcp://pool.auroraborealiscoin.com:3333 --wallet [WALLET ADDRESS] --worker ArcWorker1

pause
