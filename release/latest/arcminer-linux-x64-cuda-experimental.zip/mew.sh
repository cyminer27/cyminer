#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
./arcminer --mine --coin mewc --pool pool.woolypooly.com:3116 --wallet "[WALLET ADDRESS]" --worker ArcWorker1
read -r -p 'Press Enter to continue...' _
