#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
./arcminer --mine --coin abrs --pool stratum+tcp://pool.auroraborealiscoin.com:3333 --wallet "[WALLET ADDRESS]" --worker ArcWorker1
read -r -p 'Press Enter to continue...' _
