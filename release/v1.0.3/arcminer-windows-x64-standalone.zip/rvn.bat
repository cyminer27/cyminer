arcminer.exe --mine --coin rvn --pool stratum+tcp://stratum.ravenminer.com:3800 --wallet [WALLET ADDRESS] --worker ArcWorker2

pause