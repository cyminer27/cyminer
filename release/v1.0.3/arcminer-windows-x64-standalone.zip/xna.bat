arcminer.exe --mine --coin xna --algo kawpow --pool  us-xna.2miners.com:6060 --wallet [WALLET ADDRESS] --worker ArcWorker1
